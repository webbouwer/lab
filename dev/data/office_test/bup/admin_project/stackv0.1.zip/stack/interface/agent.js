/* Stack Agent v0.1 
 * Javascript
 */
window.onload = function(){

var $agent = new stackagent();

}

var stackagent = function(){
	
	this.agentlogon = function(){
		alert('Hi there!');
	}

	this.agentlogon();

}

